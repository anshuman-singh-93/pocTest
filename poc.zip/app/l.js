/**
 * Created by admin on 1/2/2017.
 */
var message = "Hello World";
console.log(message);
//# sourceMappingURL=l.js.map